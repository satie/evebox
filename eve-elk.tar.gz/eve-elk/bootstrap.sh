#!/bin/bash

docker-compose down -v 

docker build -t logstash ./logstash
docker build -t evebox ./evebox

docker-compose up -d
